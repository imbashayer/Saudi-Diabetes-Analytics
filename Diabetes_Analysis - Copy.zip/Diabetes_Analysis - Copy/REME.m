# Saudi Diabetes Analytics

An interactive dashboard analyzing diabetes patterns
in a synthetic Saudi population dataset.

## Features
- Diabetes prevalence analysis
- Age and gender comparisons
- Risk factor exploration
- Logistic regression
- Model diagnostics
- What-if analysis

## Installation
pip install -r requirements.txt

## Run
streamlit run app.py

## Disclaimer
This project uses synthetic data and is for educational
purposes only. It is not intended for medical diagnosis.